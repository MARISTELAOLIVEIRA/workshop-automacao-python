"""
Verificador de ambiente - Workshop de Automação com Python

Rode este arquivo ANTES do workshop:
    py verificar_ambiente.py
(se "py" não funcionar, tente: python verificar_ambiente.py)

Ele confere se a versão do Python e todas as bibliotecas estão prontas.
"""

import importlib
import sys

# nome usado no "import"  ->  nome usado no "pip install"
BIBLIOTECAS = {
    "pandas": "pandas",
    "openpyxl": "openpyxl",
    "reportlab": "reportlab",
    "matplotlib": "matplotlib",
    "requests": "requests",
    "bs4": "beautifulsoup4",
}

print("=" * 55)
print(" VERIFICANDO SEU AMBIENTE PARA O WORKSHOP")
print("=" * 55)

tudo_certo = True

versao = sys.version_info
if versao >= (3, 9):
    print(f"[OK]    Python {versao.major}.{versao.minor}.{versao.micro}")
else:
    print(f"[ERRO]  Python {versao.major}.{versao.minor} é antigo demais (precisa 3.9 ou mais novo)")
    tudo_certo = False

faltando = []
for nome_import, nome_pip in BIBLIOTECAS.items():
    try:
        importlib.import_module(nome_import)
        print(f"[OK]    {nome_pip}")
    except ImportError:
        print(f"[FALTA] {nome_pip}")
        faltando.append(nome_pip)
        tudo_certo = False

print("-" * 55)
if tudo_certo:
    print("Tudo pronto! Nos vemos no workshop :)")
else:
    if faltando:
        print("Instale o que está faltando com o comando abaixo:\n")
        print(f"    py -m pip install --user {' '.join(faltando)}\n")
        print("(se 'py' não funcionar, troque por 'python')")
    print("Se der erro, anote a mensagem e traga no dia do workshop.")
print("=" * 55)

input("\nPressione ENTER para fechar...")
