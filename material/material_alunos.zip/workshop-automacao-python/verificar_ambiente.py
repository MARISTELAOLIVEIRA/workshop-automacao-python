"""
Verificador de ambiente - Workshop de Automação com Python

Rode este arquivo ANTES do workshop:
    abra a pasta do material no VS Code, clique neste arquivo
    e depois no botão ▶ (canto superior direito).

Ele confere a versão do Python e as bibliotecas. Se faltar alguma,
oferece instalar na hora, usando o mesmo Python que o VS Code usa.
"""

import importlib
import site
import subprocess
import sys

# nome usado no "import"  ->  nome usado no "pip install"
BIBLIOTECAS = {
    "pandas": "pandas",
    "openpyxl": "openpyxl",
    "reportlab": "reportlab",
    "matplotlib": "matplotlib",
    "requests": "requests",
    "bs4": "beautifulsoup4",
}


def conferir():
    """Mostra o que está instalado e devolve a lista do que falta."""
    faltando = []
    for nome_import, nome_pip in BIBLIOTECAS.items():
        try:
            importlib.import_module(nome_import)
            print(f"[OK]    {nome_pip}")
        except ImportError:
            print(f"[FALTA] {nome_pip}")
            faltando.append(nome_pip)
    return faltando


def instalar(pacotes):
    """Instala os pacotes com o pip DESTE Python (o mesmo do botão ▶)."""
    comando = [sys.executable, "-m", "pip", "install", *pacotes]
    em_ambiente_virtual = sys.prefix != sys.base_prefix
    if not em_ambiente_virtual:
        comando.insert(4, "--user")  # não precisa ser administrador
    print("\nInstalando... (pode levar alguns minutos)\n")
    deu_certo = subprocess.run(comando).returncode == 0
    if deu_certo and not em_ambiente_virtual:
        # se a pasta de bibliotecas do usuário acabou de ser criada,
        # o Python ainda não sabe dela: avisamos aqui
        pasta_usuario = site.getusersitepackages()
        if pasta_usuario not in sys.path:
            sys.path.append(pasta_usuario)
    return deu_certo


print("=" * 55)
print(" VERIFICANDO SEU AMBIENTE PARA O WORKSHOP")
print("=" * 55)

versao = sys.version_info
versao_ok = versao >= (3, 9)
if versao_ok:
    print(f"[OK]    Python {versao.major}.{versao.minor}.{versao.micro}")
else:
    print(f"[ERRO]  Python {versao.major}.{versao.minor} é antigo demais (precisa 3.9 ou mais novo)")

faltando = conferir()

if faltando and versao_ok:
    print("-" * 55)
    resposta = input(f"Faltam {len(faltando)} biblioteca(s). Quer que eu instale agora? (s/n) ")
    if resposta.strip().lower().startswith("s"):
        if instalar(faltando):
            importlib.invalidate_caches()
            print("\nConferindo de novo:")
            faltando = conferir()
        else:
            print("\n[ERRO]  A instalação não funcionou. Veja a mensagem acima.")

print("-" * 55)
if versao_ok and not faltando:
    print("Tudo pronto! Nos vemos no workshop :)")
else:
    print("Ainda falta alguma coisa. Tire um print desta tela")
    print("e traga no dia do workshop (ou mande antes para a professora).")
print("=" * 55)
