# Desafios bônus

Terminou as duas práticas? Escolha um destes!

## Desafio 1: Relatório com gráfico

Use a planilha `inscritos.xlsx` (da Prática 2) para descobrir:

1. Quantas pessoas se inscreveram e quantas estavam presentes?
2. Qual a porcentagem de presença?
3. Quantos participantes vieram de cada curso?

Depois, faça um **gráfico de barras** com o número de participantes por curso e salve como imagem.

**Dicas:**
- `pd.read_excel("caminho/da/planilha.xlsx")` abre a planilha
- `tabela["Curso"].value_counts()` conta quantas vezes cada curso aparece
- `.plot(kind="barh")` faz um gráfico de barras horizontais
- `plt.savefig("grafico.png")` salva o gráfico

## Desafio 2: Coletando dados da internet (web scraping)

O site <https://quotes.toscrape.com> foi criado para quem está aprendendo a coletar dados da web.

1. Colete as citações das 3 primeiras páginas: o texto, o autor e as tags.
2. Salve tudo numa planilha `citacoes.xlsx`.
3. Descubra quais autores aparecem mais vezes.

**Dicas:**
- `requests.get(url)` baixa a página
- `BeautifulSoup(resposta.text, "html.parser")` transforma o HTML em algo pesquisável
- No navegador, clique com o botão direito numa citação e escolha **Inspecionar** para ver o HTML
- Cada citação fica dentro de `<div class="quote">`

> Na vida real, sempre confira se o site permite coleta automática (Termos de Uso e `/robots.txt`).

Crie um arquivo `.py` novo nesta pasta para cada desafio. As soluções serão compartilhadas no final do workshop.
