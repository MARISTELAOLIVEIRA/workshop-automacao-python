"""
PRÁTICA 2 - Certificados automáticos

Objetivo: ler a planilha "inscritos.xlsx" e gerar um certificado em PDF
para cada participante que estava presente.
Os PDFs serão salvos na pasta "certificados".

Complete as lacunas marcadas com ___ (três sublinhados).
Comece pela PARTE PRINCIPAL, lá no final do arquivo!

Desafios extras (para quem terminar antes):
  - Troque a COR do certificado (procure "cores hex" no Google)
  - Mude o texto, a data ou o nome do responsável
  - Gere certificados também para quem NÃO estava presente, com outro texto
"""

import re
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas

# ---------- CONFIGURAÇÕES DO EVENTO (pode mudar à vontade) ----------
EVENTO = "Workshop de Automação com Python"
JORNADA = "Jornada Interdisciplinar"
CARGA_HORARIA = "2 horas"
DATA = "outubro de 2026"
RESPONSAVEL = "Profª Maristela Oliveira"
COR = colors.HexColor("#1F4E79")
# --------------------------------------------------------------------

AQUI = Path(__file__).parent
PASTA_SAIDA = AQUI / "certificados"
PASTA_SAIDA.mkdir(exist_ok=True)


def nome_de_arquivo(nome):
    """'Ana Costa Silva' -> 'certificado_Ana_Costa_Silva.pdf'"""
    limpo = re.sub(r"[^\w ]", "", nome).strip().replace(" ", "_")
    return f"certificado_{limpo}.pdf"


def gerar_certificado(nome, curso):
    largura, altura = landscape(A4)
    arquivo = PASTA_SAIDA / nome_de_arquivo(nome)
    pdf = canvas.Canvas(str(arquivo), pagesize=(largura, altura))

    # moldura dupla
    pdf.setStrokeColor(COR)
    pdf.setLineWidth(6)
    pdf.rect(25, 25, largura - 50, altura - 50)
    pdf.setLineWidth(1.5)
    pdf.rect(38, 38, largura - 76, altura - 76)

    centro = largura / 2

    pdf.setFillColor(COR)
    pdf.setFont("Helvetica-Bold", 44)
    pdf.drawCentredString(centro, altura - 140, "CERTIFICADO")

    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 18)
    pdf.drawCentredString(centro, altura - 210, "Certificamos que")

    pdf.setFillColor(COR)
    pdf.setFont("Helvetica-Bold", 30)
    # LACUNA 4: escreva o NOME da pessoa no centro do certificado.
    # DICA: olhe como o "Certificamos que" foi escrito duas linhas acima.
    #       A altura aqui é: altura - 260
    ___

    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 16)
    pdf.drawCentredString(centro, altura - 300, f"estudante de {curso}, participou do {EVENTO},")
    pdf.drawCentredString(centro, altura - 325, f"realizado na {JORNADA}, com carga horária de {CARGA_HORARIA}.")

    pdf.setFont("Helvetica-Oblique", 14)
    pdf.drawCentredString(centro, altura - 375, DATA.capitalize())

    # linha de assinatura
    pdf.line(centro - 150, 110, centro + 150, 110)
    pdf.setFont("Helvetica", 13)
    pdf.drawCentredString(centro, 92, RESPONSAVEL)

    pdf.save()
    return arquivo


# ====================== PARTE PRINCIPAL ======================

# 1) ler a planilha
# LACUNA 1: use pd.read_excel() para abrir o arquivo AQUI / "inscritos.xlsx"
inscritos = ___
print(f"{len(inscritos)} inscritos na planilha.")

# 2) ficar só com quem estava presente
# LACUNA 2: qual valor da coluna "Presente" queremos manter?
# DICA: abra a planilha no Excel e veja o que está escrito nessa coluna.
presentes = inscritos[inscritos["Presente"] == ___]
print(f"{len(presentes)} estavam presentes.\n")

# 3) gerar um certificado para cada um
for _, pessoa in presentes.iterrows():
    # LACUNA 3: chame a função gerar_certificado passando o nome e o curso da pessoa.
    # DICA: o nome está em pessoa["Nome"]. E o curso?
    arquivo = gerar_certificado(___, ___)
    print(f"Gerado: {arquivo.name}")

print(f"\nPronto! Certificados salvos em: {PASTA_SAIDA}")
