"""
PRÁTICA 2 - Certificados automáticos

Objetivo: ler a planilha "inscritos.xlsx" e gerar um certificado em PDF
para cada participante que estava presente.
Os PDFs serão salvos na pasta "certificados".

Complete as lacunas marcadas com ___ (três sublinhados).
Comece pela PARTE PRINCIPAL, lá no final do arquivo!

Desafios extras (para quem terminar antes):
  - Troque a COR do certificado (procure "cores hex" no Google)
  - Mude o texto, a data ou o nome do responsável
  - Gere certificados também para quem NÃO estava presente, com outro texto
"""

# ---------------------------------------------------------------
# IMPORTAÇÕES
# ---------------------------------------------------------------
import re                  # "expressões regulares": buscar e trocar padrões em textos
from pathlib import Path   # caminhos de pastas e arquivos

# Bibliotecas EXTERNAS (instaladas com o pip):
import pandas as pd                                # ler e filtrar planilhas ("pd" é um apelido)
from reportlab.lib import colors                   # cores
from reportlab.lib.pagesizes import A4, landscape  # tamanho da folha e modo paisagem
from reportlab.pdfgen import canvas                # a "tela" onde desenhamos o PDF

# ---------- CONFIGURAÇÕES DO EVENTO (pode mudar à vontade) ----------
# Variáveis em MAIÚSCULAS são um costume do Python para "configurações"
# que não mudam durante o programa.
EVENTO = "Workshop de Automação com Python"
JORNADA = "Jornada Interdisciplinar"
INSTITUICAO = "Faculdade de Tecnologia e Inovação Senac DF"
CARGA_HORARIA = "2 horas"
DATA = "outubro de 2026"
RESPONSAVEL = "Profª Maristela Oliveira"
COR = colors.HexColor("#1F4E79")   # azul escuro, em código hexadecimal (como no CSS)
# --------------------------------------------------------------------

AQUI = Path(__file__).parent          # a pasta onde está este arquivo .py
PASTA_SAIDA = AQUI / "certificados"   # onde os PDFs vão ser salvos
PASTA_SAIDA.mkdir(exist_ok=True)      # cria a pasta (se ainda não existir)


def nome_de_arquivo(nome):
    """'Ana Costa Silva' -> 'certificado_Ana_Costa_Silva.pdf'"""
    # [^\w ] significa "qualquer coisa que NÃO seja letra, número ou espaço":
    # removemos esses caracteres para o nome do arquivo não dar problema
    limpo = re.sub(r"[^\w ]", "", nome).strip().replace(" ", "_")
    return f"certificado_{limpo}.pdf"


def gerar_certificado(nome, curso):
    """Desenha o certificado de UMA pessoa e salva o PDF. Devolve o caminho do arquivo."""
    # A4 deitado mede 842 x 595 "pontos" (1 ponto = 1/72 de polegada)
    largura, altura = landscape(A4)
    arquivo = PASTA_SAIDA / nome_de_arquivo(nome)
    pdf = canvas.Canvas(str(arquivo), pagesize=(largura, altura))

    # ATENÇÃO: no reportlab, o ponto (0, 0) é o canto INFERIOR esquerdo da folha.
    # Por isso escrevemos "altura - 140" para ficar a 140 pontos do TOPO.

    # moldura dupla: rect(x, y, largura, altura) desenha um retângulo
    pdf.setStrokeColor(COR)    # cor da LINHA
    pdf.setLineWidth(6)
    pdf.rect(25, 25, largura - 50, altura - 50)
    pdf.setLineWidth(1.5)
    pdf.rect(38, 38, largura - 76, altura - 76)

    centro = largura / 2   # o meio da folha, na horizontal

    # Para cada texto: escolhe a cor (setFillColor), a fonte e o tamanho (setFont)
    # e escreve centralizado com drawCentredString(x, y, texto)
    pdf.setFillColor(COR)
    pdf.setFont("Helvetica-Bold", 44)
    pdf.drawCentredString(centro, altura - 140, "CERTIFICADO")

    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 18)
    pdf.drawCentredString(centro, altura - 210, "Certificamos que")

    pdf.setFillColor(COR)
    pdf.setFont("Helvetica-Bold", 30)
    # LACUNA 4: escreva o NOME da pessoa no centro do certificado.
    # DICA: olhe como o "Certificamos que" foi escrito acima.
    #       A altura aqui é: altura - 260
    ___

    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica", 16)
    pdf.drawCentredString(centro, altura - 300, f"estudante do curso de {curso},")
    pdf.drawCentredString(centro, altura - 325, f"participou do {EVENTO}, com carga horária de {CARGA_HORARIA},")
    pdf.drawCentredString(centro, altura - 350, f"realizado na {JORNADA} da {INSTITUICAO}.")

    pdf.setFont("Helvetica-Oblique", 14)   # Oblique = itálico
    pdf.drawCentredString(centro, altura - 395, DATA.capitalize())   # "Outubro de 2026"

    # linha de assinatura: line(x_inicio, y_inicio, x_fim, y_fim)
    pdf.line(centro - 150, 110, centro + 150, 110)
    pdf.setFont("Helvetica", 13)
    pdf.drawCentredString(centro, 92, RESPONSAVEL)

    pdf.save()   # sem o save(), o PDF não é gravado!
    return arquivo


# ====================== PARTE PRINCIPAL ======================

# 1) ler a planilha
# o pandas transforma a planilha numa TABELA (chamada DataFrame)
# LACUNA 1: use pd.read_excel() para abrir o arquivo AQUI / "inscritos.xlsx"
inscritos = ___
print(f"{len(inscritos)} inscritos na planilha.")   # len() = quantidade de linhas

# 2) ficar só com quem estava presente
# inscritos["Presente"] == "Sim" dá Verdadeiro/Falso para cada linha;
# colocando isso entre [ ], o pandas guarda só as linhas Verdadeiras
# LACUNA 2: qual valor da coluna "Presente" queremos manter?
# DICA: abra a planilha no Excel e veja o que está escrito nessa coluna.
presentes = inscritos[inscritos["Presente"] == ___]
print(f"{len(presentes)} estavam presentes.\n")

# 3) gerar um certificado para cada um
# .iterrows() percorre a tabela linha por linha. Ele devolve dois valores:
# o número da linha (que não usamos, por isso o "_") e a linha em si ("pessoa")
for _, pessoa in presentes.iterrows():
    # LACUNA 3: chame a função gerar_certificado passando o nome e o curso da pessoa.
    # DICA: cada coluna é acessada pelo nome. O nome está em pessoa["Nome"]. E o curso?
    arquivo = gerar_certificado(___, ___)
    print(f"Gerado: {arquivo.name}")

print(f"\nPronto! Certificados salvos em: {PASTA_SAIDA}")
