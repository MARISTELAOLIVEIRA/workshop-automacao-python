# Workshop de Automação com Python: preparação

Olá, turma! 👋

No workshop da Jornada Interdisciplinar vamos fazer o computador trabalhar por nós: **organizar uma pasta inteira de arquivos em segundos** e **gerar certificados em PDF para uma turma inteira** a partir de uma planilha.

Não precisa saber programar! Só pedimos **10 minutos de preparação antes do dia**, para não perdermos tempo de prática com instalação.

## O que fazer antes do workshop

**1. Baixe e descompacte o material**

Baixe o arquivo `material_alunos.zip`, clique com o botão direito → **Extrair tudo...** e guarde a pasta num lugar fácil, como a Área de Trabalho.

**2. Abra a pasta no VS Code**

No VS Code, vá em **Arquivo → Abrir Pasta...** e escolha a pasta que você extraiu. Se aparecer a pergunta *"Você confia nos autores dos arquivos?"*, clique em **Sim, confio**.

Confira se a extensão **Python** (da Microsoft) está instalada: aperte `Ctrl+Shift+X`, procure por **Python** e, se precisar, clique em **Instalar**.

**3. Rode o verificador**

Na barra lateral, clique no arquivo `verificar_ambiente.py` e depois no botão **▶**, no canto superior direito.

Se faltar alguma biblioteca, ele pergunta se pode instalar. Digite `s` e aperte **Enter**. Pode levar alguns minutos.

Se aparecer **"Tudo pronto!"**, você está preparado(a). 🎉
Se aparecer algum **[FALTA]** ou **[ERRO]**, tire um print da tela e traga no dia (ou me mande antes).

## No dia

- Garanta que o notebook esteja **carregado**
- Deixe a pasta do material já descompactada

Até lá! 🐍
