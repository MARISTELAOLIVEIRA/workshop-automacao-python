# Workshop de Automação com Python: preparação

Olá, turma! 👋

No workshop da Jornada Interdisciplinar vamos fazer o computador trabalhar por nós: **organizar uma pasta inteira de arquivos em segundos** e **gerar certificados em PDF para uma turma inteira** a partir de uma planilha.

Não precisa saber programar! Só pedimos **10 minutos de preparação antes do dia**, para não perdermos tempo de prática com instalação.

## O que fazer antes do workshop

**1. Baixe e descompacte o material**

Baixe o arquivo `material_alunos.zip`, clique com o botão direito → **Extrair tudo...** e guarde a pasta num lugar fácil, como a Área de Trabalho.

**2. Instale as bibliotecas**

Abra a pasta extraída. Na barra de endereço do Explorer (onde aparece o caminho da pasta), apague o que estiver escrito, digite `cmd` e aperte **Enter**. Vai abrir uma tela preta já dentro da pasta. Digite:

```
py -m pip install --user -r requirements.txt
```

Espere terminar. Pode levar alguns minutos.
*Se aparecer "'py' não é reconhecido", troque `py` por `python` no comando.*

**3. Confira se está tudo certo**

Na mesma tela preta, digite:

```
py verificar_ambiente.py
```

Se aparecer **"Tudo pronto!"**, você está preparado(a). 🎉
Se aparecer algum **[FALTA]** ou **[ERRO]**, tire um print da tela e traga no dia (ou me mande antes).

## No dia

- Garanta que o notebook esteja **carregado**
- Deixe a pasta do material já descompactada

Até lá! 🐍
