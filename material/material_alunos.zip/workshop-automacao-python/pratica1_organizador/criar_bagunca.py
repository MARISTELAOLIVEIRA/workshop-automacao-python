"""
PASSO 0 - Cria uma pasta bagunçada para praticarmos.

Rode este arquivo primeiro. Ele cria a pasta "pasta_baguncada" aqui do lado,
cheia de arquivos de mentira (fotos, documentos, planilhas...) com datas variadas.

Assim treinamos sem mexer nos seus arquivos de verdade!
Pode rodar de novo quantas vezes quiser para "rebagunçar".
"""

import os
import random
import shutil
from datetime import datetime, timedelta
from pathlib import Path

PASTA = Path(__file__).parent / "pasta_baguncada"

NOMES = [
    "foto_praia", "selfie", "IMG_2024", "print_tela", "meme",
    "trabalho_final", "resumo_aula", "contrato", "curriculo", "artigo",
    "notas_semestre", "orcamento", "lista_presenca", "gastos_mes",
    "musica_favorita", "podcast_ep3", "gravacao_aula",
    "video_viagem", "tutorial", "backup_projetos", "fotos_compactadas",
    "instalador", "anotacoes", "script_teste", "slides_apresentacao",
]
EXTENSOES = [
    ".jpg", ".jpg", ".png", ".png", ".gif",
    ".pdf", ".pdf", ".docx", ".docx", ".txt",
    ".xlsx", ".xlsx", ".csv",
    ".mp3", ".mp3", ".wav",
    ".mp4", ".mp4", ".zip", ".rar",
    ".exe", ".md", ".py", ".pptx",
]

if PASTA.exists():
    shutil.rmtree(PASTA)
PASTA.mkdir()

random.seed(42)
hoje = datetime.now()
total = 0
for i in range(40):
    nome = f"{random.choice(NOMES)}_{i + 1:02d}{random.choice(EXTENSOES)}"
    arquivo = PASTA / nome
    arquivo.write_text("arquivo de exemplo para o workshop", encoding="utf-8")

    # coloca uma data de modificação aleatória nos últimos 12 meses
    data = hoje - timedelta(days=random.randint(0, 365))
    os.utime(arquivo, (data.timestamp(), data.timestamp()))
    total += 1

print(f"Pronto! {total} arquivos bagunçados criados em:")
print(PASTA)
