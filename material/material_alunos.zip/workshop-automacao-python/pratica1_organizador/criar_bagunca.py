"""
PASSO 0 - Cria uma pasta bagunçada para praticarmos.

Rode este arquivo primeiro (botão ▶ do VS Code). Ele cria a pasta "pasta_baguncada" aqui do lado,
cheia de arquivos de mentira (fotos, documentos, planilhas...) com datas variadas.

Assim treinamos sem mexer nos seus arquivos de verdade!
Pode rodar de novo quantas vezes quiser para "rebagunçar".
"""

import os                                # funções do sistema operacional (aqui: mudar a data do arquivo)
import random                            # sorteios
import shutil                            # copiar, mover e apagar pastas inteiras
from datetime import datetime, timedelta # datas e "intervalos" de tempo (ex.: 30 dias)
from pathlib import Path                 # caminhos de pastas e arquivos

# a pasta_baguncada fica ao lado deste arquivo .py
PASTA = Path(__file__).parent / "pasta_baguncada"

# nomes e extensões que vamos sortear para inventar os arquivos.
# Extensões repetidas aparecem mais vezes no sorteio.
NOMES = [
    "foto_praia", "selfie", "IMG_2024", "print_tela", "meme",
    "trabalho_final", "resumo_aula", "contrato", "curriculo", "artigo",
    "notas_semestre", "orcamento", "lista_presenca", "gastos_mes",
    "musica_favorita", "podcast_ep3", "gravacao_aula",
    "video_viagem", "tutorial", "backup_projetos", "fotos_compactadas",
    "instalador", "anotacoes", "script_teste", "slides_apresentacao",
]
EXTENSOES = [
    ".jpg", ".jpg", ".png", ".png", ".gif",
    ".pdf", ".pdf", ".docx", ".docx", ".txt",
    ".xlsx", ".xlsx", ".csv",
    ".mp3", ".mp3", ".wav",
    ".mp4", ".mp4", ".zip", ".rar",
    ".exe", ".md", ".py", ".pptx",
]

# se a pasta já existe (de uma rodada anterior), apaga tudo e começa do zero
if PASTA.exists():
    shutil.rmtree(PASTA)
PASTA.mkdir()

# seed = "semente" do sorteio: com o mesmo número, o sorteio sai sempre igual,
# então todo mundo da turma fica com a mesma bagunça
random.seed(42)
hoje = datetime.now()
total = 0
for i in range(40):   # repete 40 vezes: i vale 0, 1, 2, ..., 39
    # random.choice sorteia um item da lista; {i + 1:02d} escreve o número com 2 dígitos (01, 02...)
    nome = f"{random.choice(NOMES)}_{i + 1:02d}{random.choice(EXTENSOES)}"
    arquivo = PASTA / nome
    # cria o arquivo com um texto qualquer dentro (é um arquivo "de mentira")
    arquivo.write_text("arquivo de exemplo para o workshop", encoding="utf-8")

    # coloca uma data de modificação aleatória nos últimos 12 meses
    # (é ela que o organizador usa no desafio de separar por mês)
    data = hoje - timedelta(days=random.randint(0, 365))
    os.utime(arquivo, (data.timestamp(), data.timestamp()))   # (data de acesso, data de modificação)
    total += 1

print(f"Pronto! {total} arquivos bagunçados criados em:")
print(PASTA)
