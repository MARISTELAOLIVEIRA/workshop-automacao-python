"""
PRÁTICA 1 - Organizador de pastas

Objetivo: separar os arquivos da "pasta_baguncada" em subpastas por tipo:
Imagens, Documentos, Planilhas, Áudios, Vídeos, Compactados e Outros.

Antes de rodar, crie a bagunça: abra o criar_bagunca.py e clique no ▶.

Complete as lacunas marcadas com ___ (três sublinhados).
Se rodar com alguma lacuna vazia, o Python vai reclamar: "NameError: name '___'..."
Isso é normal! É só sinal de que ainda falta preencher alguma coisa.
"""

# ---------------------------------------------------------------
# IMPORTAÇÕES: "ferramentas" prontas que o Python já traz
# ---------------------------------------------------------------
import shutil                  # shutil = "shell utilities": copiar e MOVER arquivos
from datetime import datetime  # para trabalhar com datas
from pathlib import Path       # Path representa um caminho de pasta ou arquivo

# ---------------------------------------------------------------
# CONFIGURAÇÕES
# ---------------------------------------------------------------

# __file__ é o caminho DESTE arquivo .py; .parent é a pasta onde ele está.
# Assim o script encontra a pasta_baguncada, não importa de onde for aberto.
# O operador / junta pedaços de caminho: pasta / "subpasta"
PASTA = Path(__file__).parent / "pasta_baguncada"

# Desafio extra: mude para True para separar também por mês (ex.: Imagens/2026-03)
SEPARAR_POR_MES = False

# DICIONÁRIO: cada CHAVE (nome da categoria) aponta para uma LISTA de extensões.
# Para criar uma categoria nova, é só acrescentar uma linha aqui!
# LACUNA 1: complete as listas de Áudios e Vídeos.
# DICA: olhe na pasta_baguncada quais extensões de áudio e vídeo aparecem.
CATEGORIAS = {
    "Imagens": [".jpg", ".jpeg", ".png", ".gif"],
    "Documentos": [".pdf", ".docx", ".txt", ".md", ".pptx"],
    "Planilhas": [".xlsx", ".csv"],
    "Áudios": [___],
    "Vídeos": [___],
    "Compactados": [".zip", ".rar"],
}


# ---------------------------------------------------------------
# FUNÇÃO: um bloco de código com nome, que podemos usar várias vezes
# ---------------------------------------------------------------
def descobrir_categoria(extensao):
    """Recebe uma extensão (ex.: '.jpg') e devolve o nome da categoria."""
    # .items() devolve os pares (chave, valor) do dicionário,
    # então a cada volta temos o nome da categoria e a lista de extensões dela
    for categoria, extensoes in CATEGORIAS.items():
        # LACUNA 2: como testar se a extensão está DENTRO da lista?
        # DICA: em Python usamos a palavra "in"
        if ___:
            return categoria   # achou! "return" devolve a resposta e sai da função
    # se o for terminou sem achar, a extensão não está em nenhuma lista
    # LACUNA 3: para onde vai um arquivo que não é de nenhuma categoria?
    return ___


# ---------------------------------------------------------------
# PARTE PRINCIPAL: percorre a pasta e move cada arquivo
# ---------------------------------------------------------------
movidos = 0   # contador de arquivos movidos

# .iterdir() devolve, um por um, tudo o que existe dentro da pasta
for arquivo in PASTA.iterdir():
    # pula as subpastas, só queremos mexer nos arquivos
    if arquivo.is_dir():
        continue   # "continue" pula direto para o próximo item do for

    # arquivo.suffix devolve a extensão. Ex.: "foto.JPG" -> ".JPG"
    # .lower() deixa tudo minúsculo:   ".JPG" -> ".jpg"
    categoria = descobrir_categoria(arquivo.suffix.lower())
    destino = PASTA / categoria   # ex.: pasta_baguncada/Imagens

    if SEPARAR_POR_MES:
        # st_mtime é a data da última modificação do arquivo (em segundos);
        # fromtimestamp transforma em data e strftime formata como "2026-03"
        data = datetime.fromtimestamp(arquivo.stat().st_mtime)
        destino = destino / data.strftime("%Y-%m")

    # cria a pasta de destino (se ainda não existir)
    # parents=True: cria também as pastas "do meio", se precisar
    # exist_ok=True: não dá erro se a pasta já existir
    destino.mkdir(parents=True, exist_ok=True)

    # LACUNA 4: mova o arquivo para a pasta de destino.
    # DICA: shutil.move(de_onde, para_onde). Use str(arquivo) e str(destino / arquivo.name)
    ___

    # f-string: o que está entre { } é trocado pelo valor da variável.
    # {arquivo.name:35} reserva 35 espaços, para a saída ficar alinhada
    print(f"{arquivo.name:35} ->  {destino.relative_to(PASTA)}")
    movidos += 1   # o mesmo que: movidos = movidos + 1

print(f"\nPronto! {movidos} arquivos organizados.")
