"""
PRÁTICA 1 - Organizador de pastas

Objetivo: separar os arquivos da "pasta_baguncada" em subpastas por tipo:
Imagens, Documentos, Planilhas, Áudios, Vídeos, Compactados e Outros.

Antes de rodar, crie a bagunça: abra o criar_bagunca.py e clique no ▶.

Complete as lacunas marcadas com ___ (três sublinhados).
Se rodar com alguma lacuna vazia, o Python vai reclamar: "NameError: name '___'..."
Isso é normal! É só sinal de que ainda falta preencher alguma coisa.
"""

import shutil
from datetime import datetime
from pathlib import Path

PASTA = Path(__file__).parent / "pasta_baguncada"

# Desafio extra: mude para True para separar também por mês (ex.: Imagens/2026-03)
SEPARAR_POR_MES = False

# Cada categoria tem a sua lista de extensões.
# LACUNA 1: complete as listas de Áudios e Vídeos.
# DICA: olhe na pasta_baguncada quais extensões de áudio e vídeo aparecem.
CATEGORIAS = {
    "Imagens": [".jpg", ".jpeg", ".png", ".gif"],
    "Documentos": [".pdf", ".docx", ".txt", ".md", ".pptx"],
    "Planilhas": [".xlsx", ".csv"],
    "Áudios": [___],
    "Vídeos": [___],
    "Compactados": [".zip", ".rar"],
}


def descobrir_categoria(extensao):
    """Recebe uma extensão (ex.: '.jpg') e devolve o nome da categoria."""
    for categoria, extensoes in CATEGORIAS.items():
        # LACUNA 2: como testar se a extensão está DENTRO da lista?
        # DICA: em Python usamos a palavra "in"
        if ___:
            return categoria
    # LACUNA 3: se não achou em nenhuma categoria, para onde vai o arquivo?
    return ___


movidos = 0
for arquivo in PASTA.iterdir():
    # pula as subpastas, só queremos mexer nos arquivos
    if arquivo.is_dir():
        continue

    # arquivo.suffix devolve a extensão. Ex.: "foto.JPG" -> ".JPG"
    # .lower() deixa tudo minúsculo:   ".JPG" -> ".jpg"
    categoria = descobrir_categoria(arquivo.suffix.lower())
    destino = PASTA / categoria

    if SEPARAR_POR_MES:
        data = datetime.fromtimestamp(arquivo.stat().st_mtime)
        destino = destino / data.strftime("%Y-%m")

    # cria a pasta de destino (se ainda não existir)
    destino.mkdir(parents=True, exist_ok=True)

    # LACUNA 4: mova o arquivo para a pasta de destino.
    # DICA: shutil.move(origem, destino). Use str(arquivo) e str(destino / arquivo.name)
    ___

    print(f"{arquivo.name:35} ->  {destino.relative_to(PASTA)}")
    movidos += 1

print(f"\nPronto! {movidos} arquivos organizados.")
